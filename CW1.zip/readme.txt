# Data-Mining-Coursework
This is an answer of Data Mining Coursework 1 from Jasper Ning.

## Requirements
- Python 2.7.16
- Numpy 1.16.2
- Scikit-learn 0.20.3
- Matplotlib 2.2.3
- Pandas 0.24.2

## Run the codes
- Run `python classification.py` for answering questions in section **Classification**.
- Run `python cluster.py` for answering questions in section **Clustering**.